import React, { useState } from "react";
import { GibDocument } from "../models/gibDocument";
import { openPdfFile, sharePdfFile } from "../utils/pdfActions";
import { GIB_UNITS, getGibUnitLabel } from "../constants/gibUnits";

import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { GibService } from "../services/gib";
import {
  InvoiceDraftInput,
  nowAsGibTime,
  todayAsGibDate,
} from "../models/invoiceDraft";

import {
  GIB_TAX_TYPES,
  getGibTaxTypeLabel,
} from "../constants/gibTaxTypes";

type Props = {
  gib: GibService;
  onBack: () => void;
};

type DraftLineForm = {
  id: string;
  malHizmet: string;
  miktar: string;
  birimFiyat: string;
  kdvOrani: string;
  birim: string;
  vergiCesidi: string;
};

function createLine(): DraftLineForm {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    malHizmet: "Hizmet Bedeli",
    miktar: "1",
    birimFiyat: "100",
    kdvOrani: "20",
    birim: "C62",
    vergiCesidi: " ",
  };
}

function toNumber(value: string) {
  const normalized = value.replace(",", ".").trim();
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatMoney(value: number) {
  return value.toFixed(2);
}

function calculateLineTotal(line: DraftLineForm) {
  const miktar = toNumber(line.miktar);
  const birimFiyat = toNumber(line.birimFiyat);
  const kdvOrani = toNumber(line.kdvOrani);

  const araToplam = miktar * birimFiyat;
  const kdvTutari = (araToplam * kdvOrani) / 100;
  const genelToplam = araToplam + kdvTutari;

  return {
    miktar,
    birimFiyat,
    kdvOrani,
    araToplam,
    kdvTutari,
    genelToplam,
  };
}

export function InvoiceDraftScreen({ gib, onBack }: Props) {
  const [loading, setLoading] = useState(false);
  const [resultText, setResultText] = useState("");

  const [buyerType, setBuyerType] = useState<"corporate" | "person">("person");

  const [vknTckn, setVknTckn] = useState("1111111111");
  const [aliciUnvan, setAliciUnvan] = useState("TEST ALICI LTD ŞTİ");
  const [aliciAdi, setAliciAdi] = useState("");
  const [aliciSoyadi, setAliciSoyadi] = useState("");
  const [vergiDairesi, setVergiDairesi] = useState("TEST VERGİ DAİRESİ");

  const [adres, setAdres] = useState("Test Mahallesi Test Caddesi No:1");
  const [mahalleSemtIlce, setMahalleSemtIlce] = useState("YeniKara");
  const [sehir, setSehir] = useState("İzmir");
  const [ulke, setUlke] = useState("Türkiye");

  const [showDetailedAddress, setShowDetailedAddress] = useState(false);

  const [binaAdi, setBinaAdi] = useState("");
  const [binaNo, setBinaNo] = useState("");
  const [kapiNo, setKapiNo] = useState("");
  const [kasabaKoy, setKasabaKoy] = useState("");
  const [postaKodu, setPostaKodu] = useState("");

  const [lines, setLines] = useState<DraftLineForm[]>([createLine()]);

  const [note, setNote] = useState("");

  const totals = lines.reduce(
    (sum, line) => {
      const lineTotal = calculateLineTotal(line);

      return {
        araToplam: sum.araToplam + lineTotal.araToplam,
        kdvTutari: sum.kdvTutari + lineTotal.kdvTutari,
        genelToplam: sum.genelToplam + lineTotal.genelToplam,
      };
    },
    {
      araToplam: 0,
      kdvTutari: 0,
      genelToplam: 0,
    }
  );
  const [taxPickerLineId, setTaxPickerLineId] = useState<string | null>(null);
  const [unitPickerLineId, setUnitPickerLineId] = useState<string | null>(null);
  const [showAdvancedFields, setShowAdvancedFields] = useState(false);

  const [faturaTipi, setFaturaTipi] = useState("SATIS");
  const [paraBirimi, setParaBirimi] = useState("TRY");
  const [dovzTLkur, setDovzTLkur] = useState("0");

  const [siparisNumarasi, setSiparisNumarasi] = useState("");
  const [siparisTarihi, setSiparisTarihi] = useState("");

  const [irsaliyeNumarasi, setIrsaliyeNumarasi] = useState("");
  const [irsaliyeTarihi, setIrsaliyeTarihi] = useState("");

  const [tel, setTel] = useState("");
  const [eposta, setEposta] = useState("");
  const [websitesi, setWebsitesi] = useState("");
  const [createdDocument, setCreatedDocument] = useState<GibDocument | null>(null);
  const [createdPdfUri, setCreatedPdfUri] = useState<string | null>(null);
  const [preparingPdf, setPreparingPdf] = useState(false);
  const [activePdfAction, setActivePdfAction] = useState<"open" | "share" | null>(null);
  const [createdMessage, setCreatedMessage] = useState("");
  const [createdDraftInput, setCreatedDraftInput] =
    useState<InvoiceDraftInput | null>(null);

  function updateLine(
    id: string,
    field: keyof Omit<DraftLineForm, "id">,
    value: string
  ) {
    setLines((currentLines) => {
      return currentLines.map((line) => {
        if (line.id !== id) {
          return line;
        }

        return {
          ...line,
          [field]: value,
        };
      });
    });
  }

  function selectTaxType(value: string) {
    if (!taxPickerLineId) {
      return;
    }

    updateLine(taxPickerLineId, "vergiCesidi", value);
    setTaxPickerLineId(null);
  }

  function selectUnit(value: string) {
    if (!unitPickerLineId) {
      return;
    }

    updateLine(unitPickerLineId, "birim", value || "C62");
    setUnitPickerLineId(null);
  }

  function addLine() {
    setLines((currentLines) => [...currentLines, createLine()]);
  }

  function removeLine(id: string) {
    if (lines.length === 1) {
      Alert.alert("Uyarı", "Faturada en az bir mal/hizmet kalemi bulunmalıdır.");
      return;
    }

    setLines((currentLines) => {
      return currentLines.filter((line) => line.id !== id);
    });
  }

  function validateForm() {
    const cleanVknTckn = vknTckn.trim();

    if (!cleanVknTckn) {
      return "VKN/TCKN giriniz.";
    }

    if (buyerType === "corporate") {
      if (cleanVknTckn.length !== 10) {
        return "Kurumsal alıcı için VKN 10 haneli olmalıdır.";
      }

      if (!aliciUnvan.trim()) {
        return "Alıcı unvanı giriniz.";
      }
    }

    if (buyerType === "person") {
      if (cleanVknTckn.length !== 11) {
        return "Şahıs alıcı için TCKN 11 haneli olmalıdır.";
      }

      if (!aliciAdi.trim()) {
        return "Alıcı adı giriniz.";
      }

      if (!aliciSoyadi.trim()) {
        return "Alıcı soyadı giriniz.";
      }
    }

    if (!vergiDairesi.trim()) {
      return "Vergi dairesi giriniz.";
    }

    if (!adres.trim()) {
      return "Adres giriniz.";
    }

    if (!mahalleSemtIlce.trim()) {
      return "Mahalle / Semt / İlçe bilgisi giriniz.";
    }

    if (!sehir.trim()) {
      return "Şehir giriniz.";
    }

    if (lines.length === 0) {
      return "En az bir mal/hizmet kalemi ekleyiniz.";
    }

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const lineNo = index + 1;
      const lineTotal = calculateLineTotal(line);

      if (!line.malHizmet.trim()) {
        return `${lineNo}. kalemde mal/hizmet adı giriniz.`;
      }

      if (lineTotal.miktar <= 0) {
        return `${lineNo}. kalemde miktar 0'dan büyük olmalıdır.`;
      }

      if (lineTotal.birimFiyat <= 0) {
        return `${lineNo}. kalemde birim fiyat 0'dan büyük olmalıdır.`;
      }

      if (lineTotal.kdvOrani < 0) {
        return `${lineNo}. kalemde KDV oranı negatif olamaz.`;
      }
    }

    return "";
  }

  function resetFormAfterSuccess() {
  setLines([createLine()]);
  setNote("");
  setResultText("");

  setCreatedDraftInput(null);
  setCreatedDocument(null);
  setCreatedPdfUri(null);
  setCreatedMessage("");
  setActivePdfAction(null);
}

  function wait(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function withTimeout<T>(
    promise: Promise<T>,
    ms: number,
    message: string
  ): Promise<T> {
    let timeoutId: ReturnType<typeof setTimeout> | undefined;

    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => {
        reject(new Error(message));
      }, ms);
    });

    return Promise.race([promise, timeoutPromise]).finally(() => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    });
  }

  function buildCurrentInvoiceInput(): InvoiceDraftInput {
    return {
      vknTckn: vknTckn.trim(),

      aliciUnvan: buyerType === "corporate" ? aliciUnvan.trim() : "",
      aliciAdi: buyerType === "person" ? aliciAdi.trim() : "",
      aliciSoyadi: buyerType === "person" ? aliciSoyadi.trim() : "",

      vergiDairesi: vergiDairesi.trim(),

      adres: adres.trim(),
      mahalleSemtIlce: mahalleSemtIlce.trim(),
      sehir: sehir.trim(),
      ulke: ulke.trim() || "Türkiye",

      binaAdi: binaAdi.trim(),
      binaNo: binaNo.trim(),
      kapiNo: kapiNo.trim(),
      kasabaKoy: kasabaKoy.trim(),
      postaKodu: postaKodu.trim(),

      tarih: todayAsGibDate(),
      saat: nowAsGibTime(),

      paraBirimi: paraBirimi.trim() || "TRY",
      dovzTLkur: toNumber(dovzTLkur),
      faturaTipi: faturaTipi.trim() || "SATIS",

      siparisNumarasi: siparisNumarasi.trim(),
      siparisTarihi: siparisTarihi.trim(),

      irsaliyeNumarasi: irsaliyeNumarasi.trim(),
      irsaliyeTarihi: irsaliyeTarihi.trim(),

      tel: tel.trim(),
      eposta: eposta.trim(),
      websitesi: websitesi.trim(),

      not: note.trim(),

      lines: lines.map((line) => {
        const lineTotal = calculateLineTotal(line);

        return {
          malHizmet: line.malHizmet.trim(),
          miktar: lineTotal.miktar,
          birimFiyat: lineTotal.birimFiyat,
          kdvOrani: lineTotal.kdvOrani,
          birim: line.birim || "C62",
          vergiCesidi: line.vergiCesidi || " ",
        };
      }),
    };
  }


  function normalizeText(value: unknown) {
    return String(value ?? "")
      .toLocaleLowerCase("tr-TR")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeGibDate(value: unknown) {
    return String(value ?? "")
      .replace(/\//g, "-")
      .trim();
  }

  function extractDocumentNumber(value: unknown) {
    const match = String(value ?? "").match(/(\d+)$/);
    return match ? Number(match[1]) : 0;
  }

  function getDocValue(doc: GibDocument, key: string) {
    return String((doc as any)?.[key] ?? doc.raw?.[key] ?? "");
  }

  function buyerMatches(docBuyer: string, expectedBuyer: string) {
    if (!expectedBuyer) {
      return false;
    }

    return (
      docBuyer === expectedBuyer ||
      docBuyer.includes(expectedBuyer) ||
      expectedBuyer.includes(docBuyer)
    );
  }

  async function findCreatedDraftDocument(
    input: InvoiceDraftInput
  ): Promise<GibDocument | null> {
    const expectedDate = normalizeText(normalizeGibDate(input.tarih));
    const expectedVknTckn = normalizeText(input.vknTckn);

    const expectedBuyer = normalizeText(
      input.aliciUnvan ||
      `${input.aliciAdi} ${input.aliciSoyadi}`.trim()
    );

    for (let attempt = 1; attempt <= 4; attempt += 1) {
      if (attempt > 1) {
        await wait(1500);
      }

      const docs: GibDocument[] = await withTimeout(
        gib.getIssuedDocuments(input.tarih, input.tarih),
        12000,
        "Belge listesi alınırken zaman aşımı oluştu. Lütfen birkaç saniye sonra tekrar deneyin."
      );

      const scored = docs
        .filter((doc: GibDocument) => Boolean(doc.ettn))
        .map((doc: GibDocument) => {
          const docDate = normalizeText(
            normalizeGibDate(doc.tarih || getDocValue(doc, "belgeTarihi"))
          );

          const docVknTckn = normalizeText(
            (doc as any).aliciVknTckn ||
            doc.raw?.aliciVknTckn ||
            doc.raw?.vknTckn ||
            ""
          );

          const docBuyer = normalizeText(
            doc.alici ||
            doc.raw?.aliciUnvanAdSoyad ||
            doc.raw?.alici ||
            doc.raw?.unvan ||
            ""
          );

          const docType = normalizeText(
            doc.belgeTuru || doc.raw?.belgeTuru || "FATURA"
          );

          const approval = normalizeText(
            doc.onayDurumu || doc.raw?.onayDurumu || ""
          );

          let score = 0;
          const reasons: string[] = [];

          if (docDate === expectedDate) {
            score += 20;
            reasons.push("date");
          }

          if (docVknTckn === expectedVknTckn) {
            score += 35;
            reasons.push("vkn");
          }

          if (buyerMatches(docBuyer, expectedBuyer)) {
            score += 35;
            reasons.push("buyer");
          }

          if (docType === normalizeText("FATURA")) {
            score += 10;
            reasons.push("type");
          }

          if (approval === normalizeText("Onaylanmadı")) {
            score += 10;
            reasons.push("draft");
          }

          return {
            doc,
            score,
            reasons,
            belgeNo: doc.belgeNo,
            docNumber: extractDocumentNumber(doc.belgeNo),
            docDate,
            docVknTckn,
            docBuyer,
            docType,
            approval,
          };
        })
        .sort((a, b) => {
          if (b.score !== a.score) {
            return b.score - a.score;
          }

          return b.docNumber - a.docNumber;
        });

      console.log(
        "CREATED DRAFT MATCH ATTEMPT:",
        attempt,
        JSON.stringify(
          scored.slice(0, 10).map((item) => ({
            score: item.score,
            reasons: item.reasons,
            belgeNo: item.belgeNo,
            docNumber: item.docNumber,
            docDate: item.docDate,
            docVknTckn: item.docVknTckn,
            docBuyer: item.docBuyer,
            docType: item.docType,
            approval: item.approval,
            ettn: item.doc.ettn,
          })),
          null,
          2
        )
      );

      const best = scored[0];

      if (best && best.score >= 80) {
        return best.doc;
      }
    }

    return null;
  }

  async function getCreatedPdfUri() {
    if (createdPdfUri) {
      return createdPdfUri;
    }

    if (!createdDraftInput) {
      throw new Error(
        "Oluşturulan fatura bilgisi bulunamadı. Lütfen taslağı yeniden oluşturun."
      );
    }

    setPreparingPdf(true);

    try {
      let document = createdDocument;

      if (!document) {
        console.log("PDF için oluşturulan taslak aranıyor...");

        document = await findCreatedDraftDocument(createdDraftInput);

        if (!document) {
          throw new Error(
            "Fatura taslağı belge listesinde güvenli şekilde bulunamadı. Birkaç saniye sonra tekrar deneyin veya Faturalar ekranından listeyi yenileyin."
          );
        }

        console.log(
          "PDF için eşleşen taslak bulundu:",
          JSON.stringify(
            {
              belgeNo: document.belgeNo,
              ettn: document.ettn,
              alici: document.alici,
              tarih: document.tarih,
              onayDurumu: document.onayDurumu,
            },
            null,
            2
          )
        );

        setCreatedDocument(document);
      }

      const uri = await withTimeout(
        gib.downloadDocument(document),
        45000,
        "PDF hazırlanırken zaman aşımı oluştu. Lütfen tekrar deneyin."
      );

      setCreatedPdfUri(uri);

      return uri;
    } finally {
      setPreparingPdf(false);
    }
  }

  async function handleOpenCreatedPdf() {
    if (activePdfAction || loading) {
      return;
    }

    try {
      setActivePdfAction("open");

      const uri = await getCreatedPdfUri();

      // PDF hazırlandı. Artık butonu loading durumundan çıkarabiliriz.
      setActivePdfAction(null);

      await openPdfFile(uri);
    } catch (err: any) {
      Alert.alert(
        "PDF Görüntüleme Hatası",
        err?.message ?? "PDF görüntülenemedi."
      );
    } finally {
      setActivePdfAction(null);
      setPreparingPdf(false);
    }
  }

  async function handleShareCreatedPdf() {
    if (activePdfAction || loading) {
      return;
    }

    try {
      setActivePdfAction("share");

      const uri = await getCreatedPdfUri();

      // PDF hazırlandı. Paylaşım ekranı açılmadan önce loading'i bitirelim.
      setActivePdfAction(null);

      await sharePdfFile(uri);
    } catch (err: any) {
      Alert.alert(
        "Paylaşım Hatası",
        err?.message ?? "PDF paylaşılamadı."
      );
    } finally {
      setActivePdfAction(null);
      setPreparingPdf(false);
    }
  }

  async function handleCreateDraft() {
    const validationError = validateForm();

    if (validationError) {
      Alert.alert("Eksik Bilgi", validationError);
      return;
    }

    try {
      setLoading(true);
      setResultText("");
      setCreatedDocument(null);
      setCreatedPdfUri(null);
      setCreatedMessage("");
      setActivePdfAction(null);

      const input = buildCurrentInvoiceInput();

      console.log("FATURA TASLAK INPUT:", JSON.stringify(input, null, 2));

      const result = await gib.createInvoiceDraft(input);

      console.log("FATURA TASLAK RESULT:", JSON.stringify(result, null, 2));

      setResultText(JSON.stringify(result, null, 2));

      setCreatedDraftInput(input);
      setCreatedDocument(null);
      setCreatedPdfUri(null);

      setCreatedMessage(
        "Fatura taslağı oluşturuldu. PDF görüntüleyebilir veya paylaşabilirsiniz."
      );

      Alert.alert("Başarılı", "Fatura taslağı oluşturuldu.");
    } catch (err: any) {
      const message = err?.message ?? "Fatura taslağı oluşturulamadı.";
      setResultText(message);
      Alert.alert("Hata", message);
    } finally {
      setLoading(false);
    }
  }

  const isDraftReady = Boolean(createdDraftInput);
  const isPdfBusy = Boolean(activePdfAction) || preparingPdf;

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="none"
      >
        <View style={styles.topHeader}>
          <Pressable
            style={styles.headerBackButton}
            onPress={onBack}
            disabled={loading}
          >
            <Text style={styles.headerBackText}>‹</Text>
          </Pressable>

          <View style={styles.headerTitleBlock}>
            <Text style={styles.title}>Fatura Yaz</Text>
            <Text style={styles.subtitle}>
              Sadece taslak oluşturur, SMS onayı yapmaz.
            </Text>
          </View>

          <View style={styles.testBadge}>
            <Text style={styles.testBadgeText}>TEST</Text>
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Alıcı Bilgileri</Text>

          <View style={styles.buyerTypeRow}>

            <Pressable
              style={[
                styles.buyerTypeButton,
                buyerType === "person" && styles.buyerTypeButtonActive,
              ]}
              onPress={() => {
                setBuyerType("person");
                setVknTckn("11111111111");
                setAliciUnvan("");
              }}
              disabled={loading}
            >
              <Text
                style={[
                  styles.buyerTypeText,
                  buyerType === "person" && styles.buyerTypeTextActive,
                ]}
              >
                Şahıs
              </Text>
            </Pressable>

            <Pressable
              style={[
                styles.buyerTypeButton,
                buyerType === "corporate" && styles.buyerTypeButtonActive,
              ]}
              onPress={() => {
                setBuyerType("corporate");
                setVknTckn("1111111111");
                setAliciAdi("");
                setAliciSoyadi("");
              }}
              disabled={loading}
            >
              <Text
                style={[
                  styles.buyerTypeText,
                  buyerType === "corporate" && styles.buyerTypeTextActive,
                ]}
              >
                Kurumsal
              </Text>
            </Pressable>


          </View>

          <TextInput
            style={styles.input}
            placeholder={buyerType === "corporate" ? "VKN" : "TCKN"}
            value={vknTckn}
            onChangeText={setVknTckn}
            keyboardType="number-pad"
            maxLength={buyerType === "corporate" ? 10 : 11}
          />

          {buyerType === "corporate" ? (
            <TextInput
              style={styles.input}
              placeholder="Alıcı Unvan"
              value={aliciUnvan}
              onChangeText={setAliciUnvan}
            />
          ) : (
            <>
              <TextInput
                style={styles.input}
                placeholder="Alıcı Adı"
                value={aliciAdi}
                onChangeText={setAliciAdi}
              />

              <TextInput
                style={styles.input}
                placeholder="Alıcı Soyadı"
                value={aliciSoyadi}
                onChangeText={setAliciSoyadi}
              />
            </>
          )}

          <TextInput
            style={styles.input}
            placeholder="Vergi Dairesi"
            value={vergiDairesi}
            onChangeText={setVergiDairesi}
          />
        </View>
<View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <Text style={styles.cardTitle}>Mal / Hizmet Kalemleri</Text>

            <Pressable
              style={styles.addSmallButton}
              onPress={addLine}
              disabled={loading}
            >
              <Text style={styles.addSmallButtonText}>+ Kalem</Text>
            </Pressable>
          </View>

          {lines.map((line, index) => {
            const lineTotal = calculateLineTotal(line);

            return (
              <View key={line.id} style={styles.lineCard}>
                <View style={styles.lineHeader}>
                  <Text style={styles.lineTitle}>{index + 1}. Kalem</Text>

                  {lines.length > 1 ? (
                    <Pressable
                      style={styles.removeButton}
                      onPress={() => removeLine(line.id)}
                      disabled={loading}
                    >
                      <Text style={styles.removeButtonText}>Sil</Text>
                    </Pressable>
                  ) : null}
                </View>

                <TextInput
                  style={styles.input}
                  placeholder="Mal / Hizmet"
                  value={line.malHizmet}
                  onChangeText={(value) =>
                    updateLine(line.id, "malHizmet", value)
                  }
                />

                <View style={styles.lineInputRow}>
                
                  <TextInput
                    style={[styles.input, styles.lineInput]}
                    placeholder="Miktar"
                    value={line.miktar}
                    onChangeText={(value) =>
                      updateLine(line.id, "miktar", value)
                    }
                    keyboardType={Platform.OS === "android" ? "numeric" : "decimal-pad"}
                  >                    
                  </TextInput>
                  
                  <Pressable
                    style={[styles.selectButton, styles.lineInput]}
                    onPress={() => setUnitPickerLineId(line.id)}
                    disabled={loading}
                  >
                    <Text style={styles.selectLabel}>Birim</Text>
                    <Text style={styles.selectValue}>
                      {getGibUnitLabel(line.birim || "C62")}
                    </Text>
                  </Pressable>
                </View>

                <View style={styles.lineInputRow}>
                  <TextInput
                    style={[styles.input, styles.lineInput]}
                    placeholder="Birim Fiyat"
                    value={line.birimFiyat}
                    onChangeText={(value) =>
                      updateLine(line.id, "birimFiyat", value)
                    }
                    keyboardType="decimal-pad"
                  />

                  <TextInput
                    style={[styles.input, styles.lineInput]}
                    placeholder="KDV %"
                    value={line.kdvOrani}
                    onChangeText={(value) =>
                      updateLine(line.id, "kdvOrani", value)
                    }
                    keyboardType="decimal-pad"
                  />
                </View>

                <Pressable
                  style={styles.selectButton}
                  onPress={() => setTaxPickerLineId(line.id)}
                  disabled={loading}
                >
                  <Text style={styles.selectLabel}>Vergi Çeşidi</Text>
                  <Text style={styles.selectValue}>
                    {getGibTaxTypeLabel(line.vergiCesidi)}
                  </Text>
                </Pressable>

                <View style={styles.lineSummary}>
                  <Text style={styles.lineSummaryText}>
                    Ara Toplam: {formatMoney(lineTotal.araToplam)} TL
                  </Text>
                  <Text style={styles.lineSummaryText}>
                    KDV: {formatMoney(lineTotal.kdvTutari)} TL
                  </Text>
                  <Text style={styles.lineSummaryTotal}>
                    Kalem Toplamı: {formatMoney(lineTotal.genelToplam)} TL
                  </Text>
                </View>
              </View>
            );
          })}

          <Pressable
            style={styles.addLineButton}
            onPress={addLine}
            disabled={loading}
          >
            <Text style={styles.addLineButtonText}>+ Yeni Kalem Ekle</Text>
          </Pressable>
        </View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Adres Bilgileri</Text>

          <TextInput
            style={[styles.input, styles.noteInput]}
            placeholder="Adres"
            value={adres}
            onChangeText={setAdres}
            multiline
          />

          <TextInput
            style={styles.input}
            placeholder="Mahalle / Semt / İlçe"
            value={mahalleSemtIlce}
            onChangeText={setMahalleSemtIlce}
          />

          <TextInput
            style={styles.input}
            placeholder="Şehir"
            value={sehir}
            onChangeText={setSehir}
          />

          <Pressable
            style={styles.inlineExpandButton}
            onPress={() => setShowDetailedAddress((value) => !value)}
          >
            <Text style={styles.inlineExpandTitle}>Detaylı Adres</Text>
            <Text style={styles.inlineExpandAction}>
              {showDetailedAddress ? "Kapat" : "Aç"}
            </Text>
          </Pressable>

          {showDetailedAddress ? (
            <View style={styles.advancedContent}>
              <TextInput
                style={styles.input}
                placeholder="Bina Adı"
                value={binaAdi}
                onChangeText={setBinaAdi}
              />

              <View style={styles.lineInputRow}>
                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Bina No"
                  value={binaNo}
                  onChangeText={setBinaNo}
                />

                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Kapı No"
                  value={kapiNo}
                  onChangeText={setKapiNo}
                />
              </View>

              <TextInput
                style={styles.input}
                placeholder="Kasaba / Köy"
                value={kasabaKoy}
                onChangeText={setKasabaKoy}
              />

              <View style={styles.lineInputRow}>
                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Posta Kodu"
                  value={postaKodu}
                  onChangeText={setPostaKodu}
                  keyboardType="number-pad"
                />

                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Ülke"
                  value={ulke}
                  onChangeText={setUlke}
                />
              </View>
            </View>
          ) : null}
        </View>

        

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Fatura Toplamı</Text>

          <Text style={styles.summaryText}>
            Mal/Hizmet Toplamı: {formatMoney(totals.araToplam)} TL
          </Text>
          <Text style={styles.summaryText}>
            KDV Toplamı: {formatMoney(totals.kdvTutari)} TL
          </Text>
          <Text style={styles.totalText}>
            Ödenecek Tutar: {formatMoney(totals.genelToplam)} TL
          </Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Not</Text>

          <TextInput
            style={[styles.input, styles.noteInput]}
            placeholder="Fatura açıklaması, varsa ek not"
            value={note}
            onChangeText={setNote}
            multiline
          />
        </View>

        {__DEV__ && resultText ? (
          <View style={styles.resultBox}>
            <Text style={styles.resultTitle}>Teknik Detay</Text>
            <Text style={styles.resultText}>{resultText}</Text>
          </View>
        ) : null}

        <View style={styles.card}>
          <Pressable
            style={styles.advancedHeader}
            onPress={() => setShowAdvancedFields((value) => !value)}
          >
            <View>
              <Text style={styles.cardTitle}>Gelişmiş Alanlar</Text>
              <Text style={styles.advancedSubtitle}>
                Fatura tipi, döviz, sipariş ve irsaliye bilgileri
              </Text>
            </View>

            <Text style={styles.advancedToggle}>
              {showAdvancedFields ? "Kapat" : "Aç"}
            </Text>
          </Pressable>

          {showAdvancedFields ? (
            <View style={styles.advancedContent}>
              <Text style={styles.sectionLabel}>Fatura Ayarları</Text>

              <View style={styles.quickOptionRow}>
                <Pressable
                  style={[
                    styles.quickOption,
                    faturaTipi === "SATIS" && styles.quickOptionActive,
                  ]}
                  onPress={() => setFaturaTipi("SATIS")}
                >
                  <Text
                    style={[
                      styles.quickOptionText,
                      faturaTipi === "SATIS" && styles.quickOptionTextActive,
                    ]}
                  >
                    Satış
                  </Text>
                </Pressable>

                <Pressable
                  style={[
                    styles.quickOption,
                    faturaTipi === "IADE" && styles.quickOptionActive,
                  ]}
                  onPress={() => setFaturaTipi("IADE")}
                >
                  <Text
                    style={[
                      styles.quickOptionText,
                      faturaTipi === "IADE" && styles.quickOptionTextActive,
                    ]}
                  >
                    İade
                  </Text>
                </Pressable>

                <Pressable
                  style={[
                    styles.quickOption,
                    faturaTipi === "TEVKIFAT" && styles.quickOptionActive,
                  ]}
                  onPress={() => setFaturaTipi("TEVKIFAT")}
                >
                  <Text
                    style={[
                      styles.quickOptionText,
                      faturaTipi === "TEVKIFAT" && styles.quickOptionTextActive,
                    ]}
                  >
                    Tevkifat
                  </Text>
                </Pressable>
              </View>

              <View style={styles.lineInputRow}>
                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Para Birimi"
                  value={paraBirimi}
                  onChangeText={setParaBirimi}
                  autoCapitalize="characters"
                />

                <TextInput
                  style={[styles.input, styles.lineInput]}
                  placeholder="Döviz Kuru"
                  value={dovzTLkur}
                  onChangeText={setDovzTLkur}
                  keyboardType="decimal-pad"
                />
              </View>

              <Text style={styles.sectionLabel}>Sipariş Bilgileri</Text>

              <TextInput
                style={styles.input}
                placeholder="Sipariş Numarası"
                value={siparisNumarasi}
                onChangeText={setSiparisNumarasi}
              />

              <TextInput
                style={styles.input}
                placeholder="Sipariş Tarihi - GG/AA/YYYY"
                value={siparisTarihi}
                onChangeText={setSiparisTarihi}
              />

              <Text style={styles.sectionLabel}>İrsaliye Bilgileri</Text>

              <TextInput
                style={styles.input}
                placeholder="İrsaliye Numarası"
                value={irsaliyeNumarasi}
                onChangeText={setIrsaliyeNumarasi}
              />

              <TextInput
                style={styles.input}
                placeholder="İrsaliye Tarihi - GG/AA/YYYY"
                value={irsaliyeTarihi}
                onChangeText={setIrsaliyeTarihi}
              />

              <Text style={styles.sectionLabel}>İletişim Bilgileri</Text>

              <TextInput
                style={styles.input}
                placeholder="Telefon"
                value={tel}
                onChangeText={setTel}
                keyboardType="phone-pad"
              />

              <TextInput
                style={styles.input}
                placeholder="E-posta"
                value={eposta}
                onChangeText={setEposta}
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <TextInput
                style={styles.input}
                placeholder="Web Sitesi"
                value={websitesi}
                onChangeText={setWebsitesi}
                autoCapitalize="none"
              />
            </View>
          ) : null}
        </View>
        {createdMessage ? (
          <View style={styles.successCard}>
            <View style={styles.successHeaderRow}>
              <View style={styles.successIcon}>
                <Text style={styles.successIconText}>✓</Text>
              </View>
              <View style={styles.successTextBlock}>
                <Text style={styles.successTitle}>Taslak oluşturuldu</Text>
                <Text style={styles.successText}>{createdMessage}</Text>
              </View>
            </View>

            <Pressable
              style={styles.newInvoiceInlineButton}
              onPress={resetFormAfterSuccess}
              disabled={isPdfBusy}
            >
              <Text style={styles.newInvoiceInlineButtonText}>Yeni fatura yaz</Text>
            </Pressable>
          </View>
        ) : null}
      </ScrollView>
      <Modal
        visible={Boolean(taxPickerLineId)}
        transparent
        animationType="slide"
        onRequestClose={() => setTaxPickerLineId(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Vergi Çeşidi Seç</Text>

              <Pressable onPress={() => setTaxPickerLineId(null)}>
                <Text style={styles.modalCloseText}>Kapat</Text>
              </Pressable>
            </View>

            <ScrollView style={styles.modalList}>
              {GIB_TAX_TYPES.map((item) => (
                <Pressable
                  key={item.value}
                  style={styles.optionItem}
                  onPress={() => selectTaxType(item.value)}
                >
                  <Text style={styles.optionCode}>
                    {item.value.trim() || "-"}
                  </Text>
                  <Text style={styles.optionLabel}>{item.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal
        visible={Boolean(unitPickerLineId)}
        transparent
        animationType="slide"
        onRequestClose={() => setUnitPickerLineId(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Birim Seç</Text>

              <Pressable onPress={() => setUnitPickerLineId(null)}>
                <Text style={styles.modalCloseText}>Kapat</Text>
              </Pressable>
            </View>

            <ScrollView style={styles.modalList}>
              {GIB_UNITS.map((item) => (
                <Pressable
                  key={item.value || "empty-unit"}
                  style={styles.optionItem}
                  onPress={() => selectUnit(item.value)}
                >
                  <Text style={styles.optionCode}>
                    {item.value || "-"}
                  </Text>
                  <Text style={styles.optionLabel}>{item.label}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
      <View style={[styles.bottomBar, isDraftReady && styles.bottomBarReady]}>
        {isDraftReady ? (
          <>
            <View style={styles.bottomReadyInfo}>
              <Text style={styles.bottomReadyText}>Taslak hazır</Text>
            </View>

            <View style={styles.bottomActionRow}>
              <Pressable
                style={[styles.bottomPdfButton, isPdfBusy && styles.disabledButton]}
                onPress={handleOpenCreatedPdf}
                disabled={isPdfBusy || loading}
              >
                <Text style={styles.bottomPdfButtonText}>
                  {activePdfAction === "open" ? "Yükleniyor..." : "PDF Görüntüle"}
                </Text>
              </Pressable>

              <Pressable
                style={[styles.bottomShareButton, isPdfBusy && styles.disabledButton]}
                onPress={handleShareCreatedPdf}
                disabled={isPdfBusy || loading}
              >
                <Text style={styles.bottomShareButtonText}>
                  {activePdfAction === "share" ? "Yükleniyor..." : "Paylaş"}
                </Text>
              </Pressable>
            </View>
          </>
        ) : (
          <>
            <View>
              <Text style={styles.bottomBarLabel}>Ödenecek Tutar</Text>
              <Text style={styles.bottomBarTotal}>
                {formatMoney(totals.genelToplam)} TL
              </Text>
            </View>

            <Pressable
              style={[styles.bottomCreateButton, loading && styles.disabledButton]}
              onPress={handleCreateDraft}
              disabled={loading}
            >
              {loading ? (
                <View style={styles.loadingButtonContent}>
                  <ActivityIndicator color="#fff" size="small" />
                  <Text style={styles.bottomCreateButtonText}>Oluşturuluyor...</Text>
                </View>
              ) : (
                <Text style={styles.bottomCreateButtonText}>Taslak Oluştur</Text>
              )}
            </Pressable>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  selectButton: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#fff",
  },
  selectLabel: {
    color: "#777",
    fontSize: 12,
    marginBottom: 4,
  },
  selectValue: {
    color: "#222",
    fontWeight: "800",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.35)",
    justifyContent: "flex-end",
  },
  modalCard: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
    padding: 16,
    maxHeight: "80%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "800",
  },
  modalCloseText: {
    color: "#1f6feb",
    fontWeight: "800",
  },
  modalList: {
    maxHeight: 520,
  },
  optionItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
    paddingVertical: 12,
  },
  optionCode: {
    width: 58,
    color: "#666",
    fontWeight: "700",
  },
  optionLabel: {
    flex: 1,
    color: "#222",
  },
  flex: {
    flex: 1,
    backgroundColor: "#f4f6f8",
  },
  container: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 130,
    backgroundColor: "#f4f6f8",
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
  },
  subtitle: {
    marginTop: 6,
    color: "#555",
    lineHeight: 20,
  },
  backButton: {
    marginTop: 16,
    backgroundColor: "#e8eef7",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },
  backButtonText: {
    color: "#1f6feb",
    fontWeight: "700",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 14,
    marginTop: 14,
    gap: 10,
  },
  cardHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "800",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 12,
    fontSize: 15,
    color: "#000",
    backgroundColor: "#fff",
  },
  noteInput: {
    minHeight: 80,
    textAlignVertical: "top",
  },
  lineCard: {
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 12,
    padding: 12,
    backgroundColor: "#fafafa",
    gap: 10,
  },
  lineHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  lineTitle: {
    fontWeight: "800",
    color: "#333",
  },
  lineInputRow: {
    flexDirection: "row",
    gap: 10,
  },
  lineInput: {
    flex: 1,
  },
  lineSummary: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 10,
    gap: 4,
  },
  lineSummaryText: {
    color: "#555",
    fontSize: 13,
  },
  lineSummaryTotal: {
    fontWeight: "800",
    color: "#222",
    fontSize: 14,
  },
  addSmallButton: {
    backgroundColor: "#e8eef7",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 7,
  },
  addSmallButtonText: {
    color: "#1f6feb",
    fontWeight: "800",
  },
  addLineButton: {
    borderWidth: 1,
    borderColor: "#1f6feb",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
    backgroundColor: "#fff",
  },
  addLineButtonText: {
    color: "#1f6feb",
    fontWeight: "800",
  },
  removeButton: {
    backgroundColor: "#ffecec",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
  },
  removeButtonText: {
    color: "#b00020",
    fontWeight: "800",
  },
  summaryText: {
    color: "#444",
    fontSize: 15,
  },
  totalText: {
    marginTop: 4,
    fontWeight: "800",
    fontSize: 17,
  },
  createButton: {
    marginTop: 16,
    backgroundColor: "#1f6feb",
    borderRadius: 10,
    padding: 14,
    alignItems: "center",
  },
  createButtonText: {
    color: "#fff",
    fontWeight: "800",
    fontSize: 16,
  },
  disabledButton: {
    opacity: 0.7,
  },
  resultBox: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 14,
    marginTop: 16,
  },
  resultTitle: {
    fontWeight: "800",
    marginBottom: 8,
  },
  resultText: {
    color: "#333",
  },
  topHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 14,
  },

  headerBackButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#e5e5e5",
  },

  headerBackText: {
    fontSize: 34,
    lineHeight: 36,
    color: "#222",
    fontWeight: "600",
  },

  headerTitleBlock: {
    flex: 1,
  },

  testBadge: {
    backgroundColor: "#fff4d6",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: "#f0d58c",
  },

  testBadgeText: {
    color: "#8a6400",
    fontWeight: "800",
    fontSize: 12,
  },

  bottomBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#e5e5e5",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },

  bottomBarLabel: {
    color: "#777",
    fontSize: 12,
    marginBottom: 2,
  },

  bottomBarTotal: {
    color: "#111",
    fontSize: 18,
    fontWeight: "900",
  },

  bottomCreateButton: {
    backgroundColor: "#1f6feb",
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 13,
    minWidth: 145,
    alignItems: "center",
  },

  bottomCreateButtonText: {
    color: "#fff",
    fontWeight: "900",
    fontSize: 15,
  },
  loadingButtonContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },

  bottomBarReady: {
    gap: 10,
  },

  bottomReadyInfo: {
    minWidth: 86,
  },

  bottomReadyText: {
    color: "#176b2c",
    fontSize: 15,
    fontWeight: "900",
  },

  bottomActionRow: {
    flex: 1,
    flexDirection: "row",
    gap: 8,
  },

  bottomPdfButton: {
    flex: 1.15,
    backgroundColor: "#1f6feb",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 13,
    alignItems: "center",
  },

  bottomPdfButtonText: {
    color: "#fff",
    fontWeight: "900",
    fontSize: 14,
  },

  bottomShareButton: {
    flex: 0.85,
    backgroundColor: "#176b2c",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 13,
    alignItems: "center",
  },

  bottomShareButtonText: {
    color: "#fff",
    fontWeight: "900",
    fontSize: 14,
  },
  advancedHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },

  advancedSubtitle: {
    color: "#777",
    fontSize: 12,
    marginTop: 3,
  },

  advancedToggle: {
    color: "#1f6feb",
    fontWeight: "800",
  },

  advancedContent: {
    marginTop: 12,
    gap: 10,
  },

  sectionLabel: {
    marginTop: 6,
    color: "#444",
    fontWeight: "800",
    fontSize: 13,
  },

  quickOptionRow: {
    flexDirection: "row",
    gap: 8,
  },

  quickOption: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: "center",
    backgroundColor: "#fff",
  },

  quickOptionActive: {
    backgroundColor: "#1f6feb",
    borderColor: "#1f6feb",
  },

  quickOptionText: {
    color: "#333",
    fontWeight: "700",
    fontSize: 13,
  },

  quickOptionTextActive: {
    color: "#fff",
  },

  buyerTypeRow: {
    flexDirection: "row",
    gap: 8,
  },

  buyerTypeButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    paddingVertical: 11,
    alignItems: "center",
    backgroundColor: "#fff",
  },

  buyerTypeButtonActive: {
    backgroundColor: "#1f6feb",
    borderColor: "#1f6feb",
  },

  buyerTypeText: {
    color: "#333",
    fontWeight: "800",
  },

  buyerTypeTextActive: {
    color: "#fff",
  },
  inlineExpandButton: {
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 10,
    padding: 12,
    backgroundColor: "#fafafa",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  inlineExpandTitle: {
    color: "#333",
    fontWeight: "800",
  },

  inlineExpandAction: {
    color: "#1f6feb",
    fontWeight: "800",
  },
  successCard: {
    backgroundColor: "#eefaf1",
    borderRadius: 14,
    padding: 14,
    marginTop: 14,
    gap: 10,
    borderWidth: 1,
    borderColor: "#bde8c7",
  },

  successTitle: {
    color: "#176b2c",
    fontWeight: "900",
    fontSize: 16,
  },

  successText: {
    color: "#285c35",
    lineHeight: 20,
  },

  successHeaderRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
  },

  successIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#176b2c",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 1,
  },

  successIconText: {
    color: "#fff",
    fontWeight: "900",
  },

  successTextBlock: {
    flex: 1,
  },

  newInvoiceInlineButton: {
    alignSelf: "flex-start",
    paddingVertical: 6,
    paddingHorizontal: 4,
  },

  newInvoiceInlineButtonText: {
    color: "#1f6feb",
    fontWeight: "900",
  },

  successButtonRow: {
    flexDirection: "row",
    gap: 10,
  },

  secondaryActionButton: {
    flex: 1,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderColor: "#1f6feb",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },

  secondaryActionButtonText: {
    color: "#1f6feb",
    fontWeight: "900",
  },

  newInvoiceButton: {
    backgroundColor: "#176b2c",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },

  newInvoiceButtonText: {
    color: "#fff",
    fontWeight: "900",
  },
});